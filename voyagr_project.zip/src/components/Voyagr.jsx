export default function Voyagr() {
  return <div>Voyagr UI goes here...</div>;
}
