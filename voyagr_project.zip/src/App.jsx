import React from "react";
import Voyagr from "./components/Voyagr";

export default function App() {
  return <Voyagr />;
}
